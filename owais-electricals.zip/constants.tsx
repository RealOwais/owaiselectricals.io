
import { Service, Testimonial } from './types';

export const SERVICES: Service[] = [
  {
    id: 'res-1',
    title: 'Home Wiring & Repair',
    description: 'Complete home rewiring, outlet upgrades, and electrical panel maintenance for a safe living environment.',
    icon: 'Home',
    category: 'Residential'
  },
  {
    id: 'com-1',
    title: 'Commercial Infrastructure',
    description: 'Heavy-duty electrical systems, office lighting, and server room power solutions tailored for businesses.',
    icon: 'Building2',
    category: 'Commercial'
  },
  {
    id: 'eme-1',
    title: '24/7 Emergency Response',
    description: 'Immediate assistance for power outages, electrical fires, and hazardous wiring situations.',
    icon: 'Zap',
    category: 'Emergency'
  },
  {
    id: 'res-2',
    title: 'Smart Home Integration',
    description: 'Installation of smart lighting, security cameras, and automated thermostats for modern convenience.',
    icon: 'Cpu',
    category: 'Residential'
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: '1',
    name: 'Sarah Johnson',
    role: 'Homeowner',
    content: 'VoltMaster arrived within 30 minutes for an emergency outlet fire. Their professionalism and speed were unmatched.',
    rating: 5,
    avatar: 'https://picsum.photos/id/64/100/100'
  },
  {
    id: '2',
    name: 'Michael Chen',
    role: 'Facility Manager',
    content: 'We use them for all our warehouse electrical needs. Reliable, clean work, and always up to code.',
    rating: 5,
    avatar: 'https://picsum.photos/id/91/100/100'
  }
];


import React, { useState } from 'react';
import { Mail, Phone, MapPin, Send, CheckCircle } from 'lucide-react';

const Contact: React.FC = () => {
  const [formState, setFormState] = useState<'idle' | 'loading' | 'success'>('idle');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormState('loading');
    setTimeout(() => setFormState('success'), 1500);
  };

  return (
    <section id="contact" className="py-24 bg-white relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16">
          <div>
            <h2 className="text-base font-bold text-yellow-600 uppercase tracking-widest mb-2">Get in Touch</h2>
            <p className="text-4xl md:text-5xl font-extrabold text-slate-900 mb-6">Let's solve your electrical issues.</p>
            <p className="text-lg text-slate-600 mb-10 max-w-lg">
              Fill out the form for a non-emergency quote, or call us directly for immediate assistance. We respond to all inquiries within 2 hours.
            </p>

            <div className="space-y-6">
              {[
                { icon: Phone, label: 'Call Us', value: '(555) 012-3456', link: 'tel:5550123456' },
                { icon: Mail, label: 'Email Us', value: 'hello@owaiselectricals.com', link: 'mailto:hello@owaiselectricals.com' },
                { icon: MapPin, label: 'Visit Us', value: '123 Power Lane, Electric City, EC 90210', link: '#' },
              ].map((item, idx) => (
                <a 
                  key={idx} 
                  href={item.link}
                  className="flex items-center gap-5 group"
                >
                  <div className="w-12 h-12 bg-slate-50 rounded-2xl flex items-center justify-center group-hover:bg-yellow-400 transition-colors">
                    <item.icon className="text-slate-900" size={24} />
                  </div>
                  <div>
                    <p className="text-sm font-bold text-slate-400 uppercase tracking-wider">{item.label}</p>
                    <p className="text-lg font-bold text-slate-900 group-hover:text-yellow-600 transition-colors">{item.value}</p>
                  </div>
                </a>
              ))}
            </div>
          </div>

          <div className="bg-slate-50 p-8 md:p-12 rounded-[2.5rem] shadow-sm border border-slate-100">
            {formState === 'success' ? (
              <div className="h-full flex flex-col items-center justify-center text-center animate-in zoom-in duration-300">
                <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mb-6">
                  <CheckCircle size={40} />
                </div>
                <h3 className="text-2xl font-bold text-slate-900 mb-2">Message Sent!</h3>
                <p className="text-slate-600">Thank you for reaching out. One of our master electricians will contact you shortly.</p>
                <button 
                  onClick={() => setFormState('idle')}
                  className="mt-8 text-yellow-600 font-bold hover:underline"
                >
                  Send another message
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-700">Full Name</label>
                    <input 
                      required
                      type="text" 
                      placeholder="John Doe"
                      className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-yellow-400 transition-all"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-700">Email Address</label>
                    <input 
                      required
                      type="email" 
                      placeholder="john@example.com"
                      className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-yellow-400 transition-all"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700">Service Type</label>
                  <select className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-yellow-400 transition-all appearance-none">
                    <option>Residential Installation</option>
                    <option>Commercial Maintenance</option>
                    <option>Emergency Repair</option>
                    <option>Smart Home Setup</option>
                    <option>Other</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700">Message</label>
                  <textarea 
                    rows={4} 
                    placeholder="Tell us about your electrical needs..."
                    className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-yellow-400 transition-all resize-none"
                  ></textarea>
                </div>
                <button 
                  disabled={formState === 'loading'}
                  className="w-full bg-slate-900 text-white py-4 rounded-xl font-bold text-lg hover:bg-slate-800 transition-all flex items-center justify-center gap-3 shadow-xl shadow-slate-200"
                >
                  {formState === 'loading' ? 'Sending...' : (
                    <>
                      Send Request <Send size={20} />
                    </>
                  )}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;


import React from 'react';
import { Zap, Facebook, Twitter, Instagram, Linkedin } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-900 text-slate-400 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-12 mb-12">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center gap-2 mb-6">
              <div className="bg-yellow-400 p-2 rounded-lg">
                <Zap className="h-6 w-6 text-slate-900 fill-slate-900" />
              </div>
              <span className="text-2xl font-black tracking-tighter text-white uppercase">Owais<span className="text-yellow-500">Electricals</span></span>
            </div>
            <p className="max-w-sm text-slate-500 mb-8">
              Premium electrical services for home and business. Licensed, insured, and trusted by thousands for over 15 years.
            </p>
            <div className="flex gap-4">
              {[Facebook, Twitter, Instagram, Linkedin].map((Icon, idx) => (
                <a key={idx} href="#" className="w-10 h-10 bg-slate-800 rounded-lg flex items-center justify-center text-slate-400 hover:bg-yellow-400 hover:text-slate-900 transition-all">
                  <Icon size={20} />
                </a>
              ))}
            </div>
          </div>
          
          <div>
            <h4 className="text-white font-bold mb-6 uppercase tracking-wider text-sm">Quick Links</h4>
            <ul className="space-y-4">
              <li><a href="#services" className="hover:text-yellow-400 transition-colors">Our Services</a></li>
              <li><a href="#about" className="hover:text-yellow-400 transition-colors">About Us</a></li>
              <li><a href="#contact" className="hover:text-yellow-400 transition-colors">Contact</a></li>
              <li><a href="#reviews" className="hover:text-yellow-400 transition-colors">Client Reviews</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-white font-bold mb-6 uppercase tracking-wider text-sm">Services</h4>
            <ul className="space-y-4">
              <li><a href="#" className="hover:text-yellow-400 transition-colors">Residential Repair</a></li>
              <li><a href="#" className="hover:text-yellow-400 transition-colors">Commercial Setup</a></li>
              <li><a href="#" className="hover:text-yellow-400 transition-colors">Emergency Work</a></li>
              <li><a href="#" className="hover:text-yellow-400 transition-colors">Panel Upgrades</a></li>
            </ul>
          </div>
        </div>
        
        <div className="pt-8 border-t border-slate-800 flex flex-col md:flex-row justify-between items-center gap-4 text-xs font-bold uppercase tracking-widest">
          <p>© 2024 Owais Electricals. All Rights Reserved.</p>
          <div className="flex gap-8">
            <a href="#" className="hover:text-white">Privacy Policy</a>
            <a href="#" className="hover:text-white">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

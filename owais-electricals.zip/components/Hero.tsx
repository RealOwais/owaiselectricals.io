
import React from 'react';
import { ArrowRight, ShieldCheck, Clock, Award, Zap } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section className="relative pt-32 pb-20 overflow-hidden bg-white">
      {/* Background patterns */}
      <div className="absolute top-0 right-0 -translate-y-1/2 translate-x-1/2 w-[600px] h-[600px] bg-yellow-100 rounded-full blur-3xl opacity-30 pointer-events-none"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <div className="inline-flex items-center gap-2 bg-yellow-50 border border-yellow-200 px-3 py-1 rounded-full text-yellow-700 text-sm font-bold mb-6">
              <span className="flex h-2 w-2 rounded-full bg-yellow-500 animate-pulse"></span>
              Licensed & Fully Insured
            </div>
            <h1 className="text-5xl md:text-7xl font-extrabold text-slate-900 leading-[1.1] mb-6">
              Expert Electrical <br />
              <span className="text-yellow-500">Solutions</span> for Your <br />
              Safety & Comfort
            </h1>
            <p className="text-xl text-slate-600 mb-8 max-w-xl leading-relaxed">
              Professional residential and commercial electrical services available 24/7. From smart home setups to emergency repairs, we keep the lights on.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <a 
                href="#contact" 
                className="group inline-flex items-center justify-center gap-2 bg-slate-900 text-white px-8 py-4 rounded-xl font-bold text-lg hover:bg-slate-800 transition-all shadow-xl shadow-slate-200"
              >
                Request Free Quote
                <ArrowRight className="group-hover:translate-x-1 transition-transform" />
              </a>
              <a 
                href="#services" 
                className="inline-flex items-center justify-center px-8 py-4 rounded-xl font-bold text-lg border-2 border-slate-200 text-slate-700 hover:bg-slate-50 transition-all"
              >
                Our Services
              </a>
            </div>

            <div className="mt-12 grid grid-cols-3 gap-6 pt-8 border-t border-slate-100">
              <div className="flex flex-col items-center sm:items-start">
                <ShieldCheck className="text-yellow-500 mb-2" size={24} />
                <span className="text-sm font-bold text-slate-900">Safety First</span>
              </div>
              <div className="flex flex-col items-center sm:items-start">
                <Clock className="text-yellow-500 mb-2" size={24} />
                <span className="text-sm font-bold text-slate-900">24/7 Support</span>
              </div>
              <div className="flex flex-col items-center sm:items-start">
                <Award className="text-yellow-500 mb-2" size={24} />
                <span className="text-sm font-bold text-slate-900">10yr Warranty</span>
              </div>
            </div>
          </div>
          
          <div className="relative">
            <div className="relative rounded-[2rem] overflow-hidden shadow-2xl border-8 border-white">
              <img 
                src="https://picsum.photos/id/192/1200/1000" 
                alt="Professional Electrician at Work" 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900/40 to-transparent"></div>
            </div>
            
            {/* Floating Stats */}
            <div className="absolute -bottom-6 -left-6 bg-white p-6 rounded-2xl shadow-xl border border-slate-100 hidden sm:block">
              <div className="flex items-center gap-4">
                <div className="bg-yellow-400 p-3 rounded-xl">
                  {/* Fixed: Zap icon is now imported */}
                  <Zap className="text-slate-900" />
                </div>
                <div>
                  <p className="text-3xl font-black text-slate-900">15k+</p>
                  <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">Jobs Completed</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;

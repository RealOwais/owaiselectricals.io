
import React from 'react';
import * as Icons from 'lucide-react';
import { SERVICES } from '../constants';

const Services: React.FC = () => {
  return (
    <section id="services" className="py-24 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-base font-bold text-yellow-600 uppercase tracking-widest mb-2">Our Expertise</h2>
          <p className="text-4xl md:text-5xl font-extrabold text-slate-900 mb-4">Complete Electrical Services</p>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            From residential repairs to industrial installations, our licensed team handles it all with precision and safety.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {SERVICES.map((service) => {
            const IconComponent = (Icons as any)[service.icon];
            return (
              <div 
                key={service.id} 
                className="bg-white p-8 rounded-3xl shadow-sm hover:shadow-xl transition-all border border-slate-100 group"
              >
                <div className="w-14 h-14 bg-slate-50 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-yellow-400 transition-colors">
                  <IconComponent className="text-slate-900" size={28} />
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-3">{service.title}</h3>
                <p className="text-slate-600 leading-relaxed mb-6">
                  {service.description}
                </p>
                <div className="inline-flex items-center gap-2 text-sm font-bold text-slate-900 hover:text-yellow-600 transition-colors cursor-pointer uppercase tracking-wider">
                  Learn More <Icons.ChevronRight size={16} />
                </div>
              </div>
            );
          })}
        </div>
        
        <div className="mt-16 bg-slate-900 rounded-[2.5rem] p-8 md:p-12 overflow-hidden relative group">
          <div className="absolute top-0 right-0 w-64 h-64 bg-yellow-400 rounded-full blur-[100px] opacity-20 group-hover:opacity-30 transition-opacity"></div>
          <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8">
            <div className="max-w-xl text-center md:text-left">
              <h3 className="text-3xl font-bold text-white mb-4">Need an emergency repair?</h3>
              <p className="text-slate-400 text-lg">Our rapid response team is available 24/7 for critical electrical failures. Don't wait until it's too late.</p>
            </div>
            <a 
              href="tel:5550123456" 
              className="bg-yellow-400 text-slate-900 px-10 py-5 rounded-2xl font-black text-xl hover:scale-105 transition-transform shadow-2xl shadow-yellow-400/20"
            >
              CALL 24/7 EMERGENCY
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;

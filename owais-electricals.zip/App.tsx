
import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Services from './components/Services';
import Contact from './components/Contact';
import Footer from './components/Footer';
import GeminiAssistant from './components/GeminiAssistant';
import { Star, Quote } from 'lucide-react';
import { TESTIMONIALS } from './constants';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-50 selection:bg-yellow-400 selection:text-slate-900">
      <Navbar />
      
      <main>
        <Hero />
        
        {/* Logos / Trust Section */}
        <section className="py-12 bg-slate-50 border-y border-slate-200 overflow-hidden">
          <div className="max-w-7xl mx-auto px-4 text-center">
            <p className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-8">Trusted by local partners</p>
            <div className="flex flex-wrap justify-center gap-12 opacity-40 grayscale contrast-125">
              <span className="text-2xl font-black italic">CONSTRUCTO</span>
              <span className="text-2xl font-black italic">CITYMGT</span>
              <span className="text-2xl font-black italic">PROFIX</span>
              <span className="text-2xl font-black italic">ELEC-CORP</span>
              <span className="text-2xl font-black italic">BUILD-NET</span>
            </div>
          </div>
        </section>

        <Services />

        {/* Why Choose Us */}
        <section id="about" className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-16 items-center">
              <div className="order-2 lg:order-1 relative">
                <div className="aspect-square bg-yellow-400 rounded-[3rem] absolute -top-4 -left-4 -z-10 rotate-3"></div>
                <img 
                  src="https://picsum.photos/id/1/800/800" 
                  alt="Team of Electricians" 
                  className="rounded-[3rem] shadow-2xl relative z-10"
                />
              </div>
              <div className="order-1 lg:order-2">
                <h2 className="text-base font-bold text-yellow-600 uppercase tracking-widest mb-2">Why Owais Electricals</h2>
                <p className="text-4xl md:text-5xl font-extrabold text-slate-900 mb-8 leading-tight">Master Electricians <br /> You Can Rely On.</p>
                
                <div className="space-y-8">
                  {[
                    { title: 'Licensed & Certified', desc: 'All our technicians go through rigorous testing and background checks.' },
                    { title: 'Transparent Pricing', desc: 'No hidden fees. We provide clear, itemized quotes before we start any work.' },
                    { title: 'Quality Guarantee', desc: 'We stand by our work with a 100% satisfaction guarantee and 10-year warranty.' }
                  ].map((item, i) => (
                    <div key={i} className="flex gap-6">
                      <div className="w-8 h-8 bg-yellow-50 rounded-lg flex items-center justify-center shrink-0">
                        <span className="text-yellow-600 font-black">{i + 1}</span>
                      </div>
                      <div>
                        <h4 className="font-bold text-xl text-slate-900 mb-2">{item.title}</h4>
                        <p className="text-slate-600 leading-relaxed">{item.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Testimonials */}
        <section id="reviews" className="py-24 bg-slate-900 text-white overflow-hidden relative">
          <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_50%_50%,rgba(250,204,21,0.05),transparent_70%)]"></div>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
            <h2 className="text-base font-bold text-yellow-400 uppercase tracking-widest mb-2">Reviews</h2>
            <p className="text-4xl md:text-5xl font-extrabold mb-16">Trusted by the Community</p>
            
            <div className="grid md:grid-cols-2 gap-8">
              {TESTIMONIALS.map((t) => (
                <div key={t.id} className="bg-white/5 backdrop-blur-sm p-10 rounded-[2.5rem] border border-white/10 text-left group hover:bg-white/10 transition-all">
                  <Quote className="text-yellow-400 mb-6 group-hover:scale-110 transition-transform" size={40} />
                  <p className="text-xl text-slate-300 italic mb-8 leading-relaxed">"{t.content}"</p>
                  <div className="flex items-center gap-4">
                    <img src={t.avatar} alt={t.name} className="w-14 h-14 rounded-2xl object-cover" />
                    <div>
                      <h4 className="font-bold text-white text-lg">{t.name}</h4>
                      <p className="text-slate-500 font-bold uppercase tracking-wider text-xs">{t.role}</p>
                      <div className="flex gap-1 mt-1">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} size={14} className="text-yellow-400 fill-yellow-400" />
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <Contact />
      </main>

      <Footer />
      
      {/* Floating AI Assistant */}
      <GeminiAssistant />
    </div>
  );
};

export default App;

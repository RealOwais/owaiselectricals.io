
import { GoogleGenAI } from "@google/genai";

const SYSTEM_INSTRUCTION = `You are "Sparky", the AI Assistant for Owais Electricals. 
Your goal is to help users identify potential electrical issues and provide safety advice.
Always emphasize:
1. Safety first: If there's smoke or fire, tell them to call emergency services immediately.
2. We are licensed professionals: Encourage booking a service for any complex work.
3. Troubleshooting: Provide simple steps for minor issues like tripped breakers or GFCI resets.
4. Professional tone: Be helpful, technical but accessible, and brand-consistent.`;

export const getGeminiResponse = async (prompt: string) => {
  // Always use process.env.API_KEY directly in the named parameter.
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
      },
    });
    // Use the .text property directly, ensuring a fallback string if undefined.
    return response.text || "I'm sorry, I couldn't generate a response. Please call our 24/7 line at (555) 012-3456.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "I'm having trouble connecting right now. Please call our 24/7 line at (555) 012-3456 for immediate assistance.";
  }
};

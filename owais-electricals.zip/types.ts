
export interface Service {
  id: string;
  title: string;
  description: string;
  icon: string;
  category: 'Residential' | 'Commercial' | 'Emergency';
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  content: string;
  rating: number;
  avatar: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}
